"""OpenAI Responses streaming primitives."""
